import 'dart:convert';
import 'dart:ui';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import '../../core/theme/theme_controller.dart';
import 'task_details_screen.dart';
import 'project_edit_screen.dart';
import 'task_form_screen.dart';


class ProjectTasksScreen extends StatefulWidget {
  const ProjectTasksScreen({super.key});

  @override
  State<ProjectTasksScreen> createState() => _ProjectTasksScreenState();
}

class _ProjectTasksScreenState extends State<ProjectTasksScreen> with SingleTickerProviderStateMixin {
  // Main view mode: 0 = Projects Hub, 1 = General Tasks (Kanban)
  int _activeTopView = 0;

  List<dynamic> _projects = [];
  List<dynamic> _allTasks = [];
  List<dynamic> _employees = [];
  bool _isLoading = true;

  // Selected Project (Detailed Workspace)
  Map<String, dynamic>? _selectedProject;
  Map<String, dynamic>? _projectDetails;
  bool _isLoadingDetails = false;

  late TabController _tabController;

  // Search & Status Filter (Screenshot 3 style)
  String _taskSearchQuery = '';
  String _selectedStatusFilter = 'ALL'; // 'ALL', 'TODO', 'IN_PROGRESS', 'REVIEW', 'DONE'
  final TextEditingController _taskSearchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _refreshAll();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _taskSearchController.dispose();
    super.dispose();
  }

  Future<void> _refreshAll() async {
    setState(() => _isLoading = true);
    await Future.wait([
      _fetchProjects(),
      _fetchAllTasks(),
      _fetchEmployees(),
    ]);
    setState(() => _isLoading = false);
  }

  // 1. PROJECTS MANGWANA
  Future<void> _fetchProjects() async {
    try {
      final res = await http.get(Uri.parse('http://localhost:5000/api/projects'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          setState(() => _projects = data['data'] ?? []);
        }
      }
    } catch (_) {}
  }

  // 2. SAARE TASKS MANGWANA
  Future<void> _fetchAllTasks() async {
    try {
      final res = await http.get(Uri.parse('http://localhost:5000/api/tasks'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          setState(() => _allTasks = data['data'] ?? []);
        }
      }
    } catch (_) {}
  }

  // 3. EMPLOYEES MANGWANA
  Future<void> _fetchEmployees() async {
    try {
      final res = await http.get(Uri.parse('http://localhost:5000/api/hr/employees'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          setState(() => _employees = data['data'] ?? []);
        }
      }
    } catch (_) {}
  }

  // 4. PROJECT DETAILS MANGWANA
  Future<void> _fetchProjectDetails(int projectId) async {
    setState(() => _isLoadingDetails = true);
    try {
      final res = await http.get(Uri.parse('http://localhost:5000/api/projects/$projectId'));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['success'] == true) {
          setState(() {
            _projectDetails = data['data'];
            _isLoadingDetails = false;
          });
        }
      }
    } catch (_) {
      setState(() => _isLoadingDetails = false);
    }
  }

  // 5. TASK STATUS UPDATE (TODO -> IN_PROGRESS -> DONE)
  Future<void> _updateTaskStatus(int taskId, String newStatus) async {
    try {
      final res = await http.put(
        Uri.parse('http://localhost:5000/api/tasks/$taskId/status'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'status': newStatus}),
      );
      if (res.statusCode == 200) {
        _fetchAllTasks();
        if (_selectedProject != null) {
          _fetchProjectDetails(_selectedProject!['project_id']);
        }
        _fetchProjects();
      }
    } catch (_) {}
  }

  // 6. SUBTASK STATUS TICK / UNTICK
  Future<void> _toggleSubtask(int subtaskId, bool isCompleted) async {
    try {
      final res = await http.put(
        Uri.parse('http://localhost:5000/api/projects/subtasks/$subtaskId'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'is_completed': isCompleted}),
      );
      if (res.statusCode == 200) {
        _fetchAllTasks();
        if (_selectedProject != null) {
          _fetchProjectDetails(_selectedProject!['project_id']);
        }
      }
    } catch (_) {}
  }

  // ================= 🗑️ MAST ULTRA-CLEAN DELETE PROJECT MODAL =================
  void _confirmDeleteProject(Map<String, dynamic> prj) {
    showDialog(
      context: context,
      builder: (ctx) {
        final isDark = ThemeController.isDarkMode.value;
        final dialogBg = isDark ? const Color(0xFF0B132B) : Colors.white;
        final textTitle = isDark ? Colors.white : const Color(0xFF0F172A);
        final textSub = isDark ? Colors.white.withValues(alpha: 0.65) : const Color(0xFF64748B);

        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
          child: Container(
            width: 440,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: dialogBg,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Colors.redAccent.withValues(alpha: 0.25), width: 1.5),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.35),
                  blurRadius: 30,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Glowing Warning Icon
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.redAccent.withValues(alpha: 0.12),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.redAccent.withValues(alpha: 0.3), width: 2),
                  ),
                  child: const Icon(Icons.delete_forever_rounded, color: Colors.redAccent, size: 36),
                ),
                const SizedBox(height: 18),

                Text(
                  'Delete Project?',
                  style: TextStyle(color: textTitle, fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),

                RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    style: TextStyle(color: textSub, fontSize: 13, height: 1.45),
                    children: [
                      const TextSpan(text: 'Are you sure you want to delete '),
                      TextSpan(
                        text: '"${prj['project_name']}"',
                        style: TextStyle(color: textTitle, fontWeight: FontWeight.bold),
                      ),
                      TextSpan(
                        text: ' (${prj['project_code']})?\n\n',
                        style: const TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF10B981)),
                      ),
                      const TextSpan(
                        text: '⚠️ All associated tasks, subtasks checklist, timesheets and deliverables will be permanently deleted.',
                        style: TextStyle(color: Colors.redAccent, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Action Buttons
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          side: BorderSide(color: textSub.withValues(alpha: 0.3)),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: () => Navigator.pop(ctx),
                        child: Text('Keep Project', style: TextStyle(color: textTitle, fontWeight: FontWeight.w600)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.redAccent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          elevation: 0,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: () async {
                          Navigator.pop(ctx);
                          try {
                            final res = await http.delete(
                              Uri.parse('http://localhost:5000/api/projects/${prj['project_id']}'),
                            );
                            if (res.statusCode == 200) {
                              if (_selectedProject != null && _selectedProject!['project_id'] == prj['project_id']) {
                                setState(() => _selectedProject = null);
                              }
                              _refreshAll();
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Project deleted successfully!'),
                                  backgroundColor: Colors.redAccent,
                                  behavior: SnackBarBehavior.floating,
                                ),
                              );
                            }
                          } catch (e) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Error: $e'), backgroundColor: Colors.redAccent),
                            );
                          }
                        },
                        icon: const Icon(Icons.delete_outline, size: 18),
                        label: const Text('Yes, Delete', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ================= ✏️ EDIT PROJECT (DEDICATED FULL SCREEN) =================
  void _openEditProjectDialog(Map<String, dynamic> prj) async {
    final res = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProjectEditScreen(
          project: prj,
          onProjectUpdated: () {
            _fetchProjects();
            if (_selectedProject != null) {
              _fetchProjectDetails(_selectedProject!['project_id']);
            }
          },
        ),
      ),
    );
    if (res == true) {
      _fetchProjects();
      if (_selectedProject != null) {
        _fetchProjectDetails(_selectedProject!['project_id']);
      }
    }
  }
  // ================= 🗑️ MAST DELETE TASK CONFIRMATION MODAL =================
  void _confirmDeleteTask(Map<String, dynamic> task) {
    showDialog(
      context: context,
      builder: (ctx) {
        final isDark = ThemeController.isDarkMode.value;
        final dialogBg = isDark ? const Color(0xFF0B132B) : Colors.white;
        final textTitle = isDark ? Colors.white : const Color(0xFF0F172A);
        final textSub = isDark ? Colors.white.withValues(alpha: 0.65) : const Color(0xFF64748B);

        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
          child: Container(
            width: 420,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: dialogBg,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: Colors.redAccent.withValues(alpha: 0.25), width: 1.5),
              boxShadow: [
                BoxShadow(color: Colors.black.withValues(alpha: 0.35), blurRadius: 30, offset: const Offset(0, 10)),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: Colors.redAccent.withValues(alpha: 0.12),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.redAccent.withValues(alpha: 0.3), width: 1.5),
                  ),
                  child: const Icon(Icons.delete_sweep_rounded, color: Colors.redAccent, size: 32),
                ),
                const SizedBox(height: 16),
                Text('Delete Task?', style: TextStyle(color: textTitle, fontSize: 19, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text(
                  'Are you sure you want to remove "${task['title']}"?\nAll associated subtasks and checklist items will be removed.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: textSub, fontSize: 13, height: 1.4),
                ),
                const SizedBox(height: 22),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: () => Navigator.pop(ctx),
                        child: Text('Cancel', style: TextStyle(color: textTitle)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.redAccent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 13),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: () async {
                          Navigator.pop(ctx);
                          try {
                            final res = await http.delete(
                              Uri.parse('http://localhost:5000/api/tasks/${task['task_id']}'),
                            );
                            print("DELETE STATUS: ${res.statusCode} -> ${res.body}");

                            if (res.statusCode == 200) {
                              _refreshAll();
                              if (_selectedProject != null) {
                                _fetchProjectDetails(_selectedProject!['project_id']);
                              }
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Task deleted successfully!'), backgroundColor: Colors.redAccent),
                              );
                            } else {
                              // Agar 404 ya 500 error aaye toh screen par red message aayega!
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('Delete Error: ${res.statusCode} - ${res.body}'), backgroundColor: Colors.red),
                              );
                            }
                          } catch (_) {}
                        },
                        child: const Text('Delete Task', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ================= ➕ ADD COMPONENT / MATERIAL DIALOG =================
  void _openAddComponentDialog(int projectId) {
    final nameCtrl = TextEditingController();
    final qtyCtrl = TextEditingController();
    final costCtrl = TextEditingController();
    String selectedUnit = 'PCS';
    String selectedStatus = 'Required';
    final formKey = GlobalKey<FormState>();
    bool isSaving = false;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setModalState) {
          final isDark = ThemeController.isDarkMode.value;
          final dialogBg = isDark ? const Color(0xFF0F172A) : Colors.white;
          final inputBg = isDark ? const Color(0xFF1E293B) : const Color(0xFFF8FAFC);
          final inputBorder = isDark ? Colors.white.withValues(alpha: 0.12) : const Color(0xFFE2E8F0);
          final titleColor = isDark ? Colors.white : const Color(0xFF0F172A);
          final subColor = isDark ? Colors.white.withValues(alpha: 0.6) : const Color(0xFF64748B);

          return Dialog(
            backgroundColor: Colors.transparent,
            insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: Container(
              width: 480,
              decoration: BoxDecoration(
                color: dialogBg,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: inputBorder),
                boxShadow: [
                  BoxShadow(color: Colors.black.withValues(alpha: 0.35), blurRadius: 30, offset: const Offset(0, 10)),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Header Banner
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                        decoration: const BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Color(0xFF2563EB), Color(0xFF1D4ED8)],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.2), borderRadius: BorderRadius.circular(10)),
                              child: const Icon(Icons.memory_rounded, color: Colors.white, size: 20),
                            ),
                            const SizedBox(width: 12),
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Add Project Component', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                                  SizedBox(height: 2),
                                  Text('Assign raw material or hardware component', style: TextStyle(color: Colors.white, fontSize: 11)),
                                ],
                              ),
                            ),
                            InkWell(
                              onTap: () => Navigator.pop(ctx),
                              borderRadius: BorderRadius.circular(20),
                              child: Container(
                                padding: const EdgeInsets.all(5),
                                decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.25), shape: BoxShape.circle),
                                child: const Icon(Icons.close, color: Colors.white, size: 16),
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Form Body
                      Padding(
                        padding: const EdgeInsets.all(20),
                        child: Form(
                          key: formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Component Name *', style: TextStyle(color: titleColor, fontSize: 12, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 6),
                              TextFormField(
                                controller: nameCtrl,
                                style: TextStyle(color: titleColor, fontSize: 13),
                                decoration: InputDecoration(
                                  hintText: 'e.g. M10 High Tensile Bolts, Mild Steel Sheet 10mm',
                                  filled: true,
                                  fillColor: inputBg,
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: inputBorder)),
                                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: inputBorder)),
                                ),
                                validator: (v) => v!.trim().isEmpty ? 'Component name is required' : null,
                              ),
                              const SizedBox(height: 14),

                              // Quantity & Unit
                              Row(
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('Quantity Required *', style: TextStyle(color: titleColor, fontSize: 12, fontWeight: FontWeight.bold)),
                                        const SizedBox(height: 6),
                                        TextFormField(
                                          controller: qtyCtrl,
                                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                          style: TextStyle(color: titleColor, fontSize: 13),
                                          decoration: InputDecoration(
                                            hintText: 'e.g. 500',
                                            filled: true,
                                            fillColor: inputBg,
                                            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: inputBorder)),
                                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: inputBorder)),
                                          ),
                                          validator: (v) => v!.trim().isEmpty ? 'Enter qty' : null,
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    flex: 1,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text('Unit', style: TextStyle(color: titleColor, fontSize: 12, fontWeight: FontWeight.bold)),
                                        const SizedBox(height: 6),
                                        DropdownButtonFormField<String>(
                                          value: selectedUnit,
                                          dropdownColor: dialogBg,
                                          decoration: InputDecoration(
                                            filled: true,
                                            fillColor: inputBg,
                                            contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 11),
                                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: inputBorder)),
                                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: inputBorder)),
                                          ),
                                          items: ['PCS', 'KG', 'MTR', 'LTR', 'SET', 'BOX', 'NOS'].map((u) {
                                            return DropdownMenuItem(value: u, child: Text(u, style: TextStyle(color: titleColor, fontSize: 12)));
                                          }).toList(),
                                          onChanged: (val) => setModalState(() => selectedUnit = val ?? 'PCS'),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 14),

                              // Status Dropdown
                              Text('Initial Status', style: TextStyle(color: titleColor, fontSize: 12, fontWeight: FontWeight.bold)),
                              const SizedBox(height: 6),
                              DropdownButtonFormField<String>(
                                value: selectedStatus,
                                dropdownColor: dialogBg,
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: inputBg,
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: inputBorder)),
                                  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: inputBorder)),
                                ),
                                items: ['Required', 'Issued', 'Consumed', 'Returned'].map((s) {
                                  return DropdownMenuItem(value: s, child: Text(s, style: TextStyle(color: titleColor, fontSize: 12)));
                                }).toList(),
                                onChanged: (val) => setModalState(() => selectedStatus = val ?? 'Required'),
                              ),
                              const SizedBox(height: 20),

                              // Action Buttons
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Cancel', style: TextStyle(color: subColor))),
                                  const SizedBox(width: 8),
                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: const Color(0xFF2563EB),
                                      foregroundColor: Colors.white,
                                      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                                    ),
                                    onPressed: isSaving
                                        ? null
                                        : () async {
                                      if (formKey.currentState!.validate()) {
                                        setModalState(() => isSaving = true);
                                        try {
                                          final res = await http.post(
                                            Uri.parse('http://localhost:5000/api/projects/$projectId/materials'),
                                            headers: {'Content-Type': 'application/json'},
                                            body: jsonEncode({
                                              'material_name': nameCtrl.text.trim(),
                                              'unit': selectedUnit,
                                              'quantity_required': double.tryParse(qtyCtrl.text.trim()) ?? 1.0,
                                              'cost_per_unit': double.tryParse(costCtrl.text.trim()) ?? 0.0,
                                            }),
                                          );
                                          if (res.statusCode == 201) {
                                            Navigator.pop(ctx);
                                            _fetchProjectDetails(projectId);
                                            ScaffoldMessenger.of(context).showSnackBar(
                                              const SnackBar(content: Text('Component added successfully!'), backgroundColor: Color(0xFF10B981)),
                                            );
                                          }
                                        } catch (_) {}
                                        setModalState(() => isSaving = false);
                                      }
                                    },
                                    child: isSaving
                                        ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                        : const Text('Add Component', style: TextStyle(fontWeight: FontWeight.bold)),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // ================= 🗑️ DELETE COMPONENT CONFIRMATION MODAL =================
  void _confirmDeleteComponent(Map<String, dynamic> m) {
    showDialog(
      context: context,
      builder: (ctx) {
        final isDark = ThemeController.isDarkMode.value;
        final dialogBg = isDark ? const Color(0xFF0B132B) : Colors.white;
        final textTitle = isDark ? Colors.white : const Color(0xFF0F172A);
        final textSub = isDark ? Colors.white.withValues(alpha: 0.65) : const Color(0xFF64748B);

        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
          child: Container(
            width: 400,
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              color: dialogBg,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.redAccent.withValues(alpha: 0.25)),
              boxShadow: [
                BoxShadow(color: Colors.black.withValues(alpha: 0.35), blurRadius: 25, offset: const Offset(0, 10)),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: Colors.redAccent.withValues(alpha: 0.12), shape: BoxShape.circle),
                  child: const Icon(Icons.delete_sweep_rounded, color: Colors.redAccent, size: 28),
                ),
                const SizedBox(height: 14),
                Text('Remove Component?', style: TextStyle(color: textTitle, fontSize: 17, fontWeight: FontWeight.bold)),
                const SizedBox(height: 6),
                Text(
                  'Are you sure you want to remove "${m['material_name']}" from this project?',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: textSub, fontSize: 12.5),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: Text('Cancel', style: TextStyle(color: textTitle)),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white),
                        onPressed: () async {
                          Navigator.pop(ctx);
                          try {
                            final res = await http.delete(
                              Uri.parse('http://localhost:5000/api/projects/materials/${m['material_id']}'),
                            );
                            if (res.statusCode == 200) {
                              if (_selectedProject != null) {
                                _fetchProjectDetails(_selectedProject!['project_id']);
                              }
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('Component removed successfully!'), backgroundColor: Colors.redAccent),
                              );
                            }
                          } catch (_) {}
                        },
                        child: const Text('Delete', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ================= ✏️ EDIT TASK (DEDICATED FULL SCREEN) =================
  void _openEditTaskDialog(Map<String, dynamic> task) async {
    final res = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TaskFormScreen(
          task: task,
          projects: _projects,
          employees: _employees,
          onTaskSaved: () {
            _refreshAll();
            if (_selectedProject != null) {
              _fetchProjectDetails(_selectedProject!['project_id']);
            }
          },
        ),
      ),
    );
    if (res == true) {
      _refreshAll();
      if (_selectedProject != null) {
        _fetchProjectDetails(_selectedProject!['project_id']);
      }
    }
  }

  // ================= 🔍 FULL TASK DETAILS & CHECKLIST MODAL =================
  
  void _openAddSubtaskDialog(dynamic taskId, String? taskTitle) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TaskDetailsScreen(
          taskId: taskId,
          projectId: _selectedProject?['project_id'],
          employees: _employees,
          onTaskUpdated: () {
            _refreshAll();
            if (_selectedProject != null) {
              _fetchProjectDetails(_selectedProject!['project_id']);
            }
          },
        ),
      ),
    ).then((_) {
      _refreshAll();
      if (_selectedProject != null) {
        _fetchProjectDetails(_selectedProject!['project_id']);
      }
    });
  }

  void _openTaskDetailsDialog(dynamic task) {
    final Map<String, dynamic> taskMap = task is Map ? Map<String, dynamic>.from(task) : <String, dynamic>{};
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TaskDetailsScreen(
          taskId: taskMap['task_id'],
          initialTask: taskMap,
          projectId: taskMap['project_id'] ?? _selectedProject?['project_id'],
          employees: _employees,
          onTaskUpdated: () {
            _refreshAll();
            if (_selectedProject != null) {
              _fetchProjectDetails(_selectedProject!['project_id']);
            }
          },
        ),
      ),
    ).then((_) {
      _refreshAll();
      if (_selectedProject != null) {
        _fetchProjectDetails(_selectedProject!['project_id']);
      }
    });
  }

  // ================= 📝 CREATE TASK (DEDICATED FULL SCREEN) =================
  void _openCreateTaskDialog({int? preselectedProjectId}) async {
    final res = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => TaskFormScreen(
          preselectedProjectId: preselectedProjectId,
          projects: _projects,
          employees: _employees,
          onTaskSaved: () {
            _refreshAll();
            if (_selectedProject != null) {
              _fetchProjectDetails(_selectedProject!['project_id']);
            }
          },
        ),
      ),
    );
    if (res == true) {
      _refreshAll();
      if (_selectedProject != null) {
        _fetchProjectDetails(_selectedProject!['project_id']);
      }
    }
  }

  // ================= 🏗️ CREATE PROJECT (DEDICATED FULL SCREEN) =================
  void _openCreateProjectDialog() async {
    final res = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProjectEditScreen(
          nextProjectNumber: 100 + _projects.length + 1,
          onProjectUpdated: _refreshAll,
        ),
      ),
    );
    if (res == true) {
      _refreshAll();
    }
  }
  // ================= 🎨 MAIN BUILD =================
  @override
  Widget build(BuildContext context) {
    final isDark = ThemeController.isDarkMode.value;
    final cardBg = isDark ? const Color(0xFF030D08).withValues(alpha: 0.5) : Colors.white.withValues(alpha: 0.42);
    final cardBorder = isDark ? Colors.white.withValues(alpha: 0.12) : Colors.white.withValues(alpha: 0.7);
    final textTitle = isDark ? Colors.white : const Color(0xFF0F172A);
    final textSub = isDark ? Colors.white.withValues(alpha: 0.6) : const Color(0xFF334155);

    // AGAR KOI PROJECT KHULA HAI TOH USKA WORKSPACE DIKHAO
    if (_selectedProject != null) {
      return _buildProjectWorkspaceView(cardBg, cardBorder, textTitle, textSub, isDark);
    }

    // MAIN SCREEN: TOP SWITCHER (Projects vs General Tasks)
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // 1. TOP HEADER & SWITCHER
        ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
              decoration: BoxDecoration(
                color: cardBg,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: cardBorder, width: 1.2),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.15),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        _buildViewTabButton(0, '📦 Projects', Icons.folder_copy_outlined, textTitle),
                        _buildViewTabButton(1, '⚡ General Tasks', Icons.bolt_rounded, textTitle),
                      ],
                    ),
                  ),
                  const Spacer(),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF059669),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    ),
                    onPressed: () {
                      if (_activeTopView == 0) {
                        _openCreateProjectDialog();
                      } else {
                        _openCreateTaskDialog(preselectedProjectId: null);
                      }
                    },
                    icon: const Icon(Icons.add_rounded, size: 20),
                    label: Text(
                      _activeTopView == 0 ? ' New Project' : ' Assign Task',
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 18),

        // 2. ACTIVE VIEW
        if (_isLoading)
          const Center(child: Padding(padding: EdgeInsets.all(40), child: CircularProgressIndicator(color: Color(0xFF10B981))))
        else if (_activeTopView == 0)
          _buildProjectsGridView(cardBg, cardBorder, textTitle, textSub)
        else
          _buildGeneralTasksKanbanView(cardBg, cardBorder, textTitle, textSub),
      ],
    );
  }

  Widget _buildViewTabButton(int index, String label, IconData icon, Color textColor) {
    final isSelected = _activeTopView == index;
    return InkWell(
      onTap: () => setState(() => _activeTopView = index),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF10B981) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Row(
          children: [
            Icon(icon, size: 16, color: isSelected ? Colors.white : textColor.withValues(alpha: 0.7)),
            const SizedBox(width: 6),
            Text(label, style: TextStyle(color: isSelected ? Colors.white : textColor, fontWeight: isSelected ? FontWeight.bold : FontWeight.w500, fontSize: 13)),
          ],
        ),
      ),
    );
  }

  // ================= 📂 VIEW A: PROJECTS GRID =================
  Widget _buildProjectsGridView(Color cardBg, Color cardBorder, Color textTitle, Color textSub) {
    if (_projects.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(40),
          child: Text('No active projects found. Click "+ New Project" to add one!', style: TextStyle(color: textSub)),
        ),
      );
    }

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 460,
        mainAxisExtent: 210,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
      ),
      itemCount: _projects.length,
      itemBuilder: (context, index) {
        final prj = _projects[index];
        final isDark = ThemeController.isDarkMode.value;
        final totalTasks = prj['total_tasks'] ?? 0;
        final completedTasks = prj['completed_tasks'] ?? 0;
        final progress = totalTasks > 0 ? (completedTasks / totalTasks) : 0.0;


        return ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: InkWell(
              onTap: () {
                setState(() => _selectedProject = prj);
                _fetchProjectDetails(prj['project_id']);
              },
              borderRadius: BorderRadius.circular(18),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: cardBg,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: cardBorder, width: 1.2),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Row(
                children: [
                Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF10B981).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(prj['project_code'] ?? 'PRJ', style: const TextStyle(color: Color(0xFF10B981), fontSize: 11, fontWeight: FontWeight.bold)),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF059669).withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(prj['status'] ?? 'Active', style: const TextStyle(color: Color(0xFF059669), fontSize: 11, fontWeight: FontWeight.bold)),
              ),
              const SizedBox(width: 4),
              // 3-DOTS OPTIONS MENU (Edit & Delete)
                  // ================= 🌟 ULTRA-SLEEK FLOATING OPTIONS MENU =================
                  Theme(
                    data: Theme.of(context).copyWith(
                      cardColor: isDark ? const Color(0xFF0F172A) : Colors.white,
                    ),
                    child: PopupMenuButton<String>(
                      // 1. Sleek Icon Trigger Pill
                      icon: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: isDark ? Colors.white.withValues(alpha: 0.08) : Colors.black.withValues(alpha: 0.05),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: isDark ? Colors.white.withValues(alpha: 0.12) : const Color(0xFFE2E8F0),
                          ),
                        ),
                        child: Icon(
                          Icons.more_vert_rounded,
                          size: 16,
                          color: textTitle.withValues(alpha: 0.8),
                        ),
                      ),
                      padding: EdgeInsets.zero,
                      elevation: 12,
                      shadowColor: Colors.black.withValues(alpha: 0.3),
                      offset: const Offset(0, 38), // Thoda neeche khulega cleanly
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: BorderSide(
                          color: isDark ? Colors.white.withValues(alpha: 0.12) : const Color(0xFFE2E8F0),
                          width: 1.2,
                        ),
                      ),
                      onSelected: (val) {
                        if (val == 'edit') {
                          _openEditProjectDialog(prj);
                        } else if (val == 'delete') {
                          _confirmDeleteProject(prj);
                        }
                      },
                      itemBuilder: (ctx) => [
                        // A. Edit Option
                        PopupMenuItem<String>(
                          value: 'edit',
                          height: 44,
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF10B981).withValues(alpha: 0.14),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Icon(Icons.edit_outlined, size: 15, color: Color(0xFF10B981)),
                              ),
                              const SizedBox(width: 12),
                              Text(
                                'Edit Project',
                                style: TextStyle(color: textTitle, fontSize: 13, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                        ),

                        // Divider Line
                        PopupMenuDivider(
                          height: 1,
                        ),

                        // B. Delete Option
                        PopupMenuItem<String>(
                          value: 'delete',
                          height: 44,
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.redAccent.withValues(alpha: 0.14),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Icon(Icons.delete_outline_rounded, size: 15, color: Colors.redAccent),
                              ),
                              const SizedBox(width: 12),
                              const Text(
                                'Delete Project',
                                style: TextStyle(color: Colors.redAccent, fontSize: 13, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
                    const SizedBox(height: 10),
                    Text(prj['project_name'] ?? 'Untitled Project', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: textTitle, fontSize: 16, fontWeight: FontWeight.bold)),
                    if (prj['client_name'] != null && prj['client_name'].toString().isNotEmpty) ...[
                      const SizedBox(height: 3),
                      Text('Product / Client: ${prj['client_name']}', style: TextStyle(color: textSub, fontSize: 12)),
                    ],
                    const Spacer(),
                    Row(
                      children: [
                        const Icon(Icons.person_pin_rounded, color: Color(0xFF10B981), size: 16),
                        const SizedBox(width: 5),
                        Text('Lead: ${prj['leader_name'] ?? 'Unassigned'}', style: TextStyle(color: textTitle, fontSize: 12, fontWeight: FontWeight.w600)),
                        const Spacer(),
                        const Icon(Icons.people_alt_outlined, color: Color(0xFF2563EB), size: 15),
                        const SizedBox(width: 4),
                        Text('${prj['total_members'] ?? 1} Members', style: TextStyle(color: textSub, fontSize: 12)),
                      ],
                    ),
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(
                        value: progress,
                        minHeight: 6,
                        backgroundColor: Colors.white.withValues(alpha: 0.1),
                        valueColor: const AlwaysStoppedAnimation(Color(0xFF10B981)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ================= ⚡ VIEW B: GENERAL TASKS (KANBAN BOARD) =================
  Widget _buildGeneralTasksKanbanView(Color cardBg, Color cardBorder, Color textTitle, Color textSub) {
    final generalTasks = _allTasks.where((t) => t['project_id'] == null).toList();

    final todo = generalTasks.where((t) => t['status'] == 'TODO').toList();
    final inProgress = generalTasks.where((t) => t['status'] == 'IN_PROGRESS').toList();
    final done = generalTasks.where((t) => t['status'] == 'DONE').toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('General & Ad-hoc Tasks (${generalTasks.length})', style: TextStyle(color: textTitle, fontWeight: FontWeight.bold, fontSize: 16)),
            Text('Standalone tasks not tied to a specific project', style: TextStyle(color: textSub, fontSize: 12)),
          ],
        ),
        const SizedBox(height: 14),

        LayoutBuilder(
          builder: (context, constraints) {
            final isMobile = constraints.maxWidth < 800;
            if (isMobile) {
              return Column(
                children: [
                  _buildKanbanColumn('To Do', todo, const Color(0xFF64748B), cardBg, cardBorder, textTitle, textSub),
                  const SizedBox(height: 16),
                  _buildKanbanColumn('In Progress', inProgress, const Color(0xFFD97706), cardBg, cardBorder, textTitle, textSub),
                  const SizedBox(height: 16),
                  _buildKanbanColumn('Completed', done, const Color(0xFF10B981), cardBg, cardBorder, textTitle, textSub),
                ],
              );
            }

            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(child: _buildKanbanColumn('To Do', todo, const Color(0xFF64748B), cardBg, cardBorder, textTitle, textSub)),
                const SizedBox(width: 14),
                Expanded(child: _buildKanbanColumn('In Progress', inProgress, const Color(0xFFD97706), cardBg, cardBorder, textTitle, textSub)),
                const SizedBox(width: 14),
                Expanded(child: _buildKanbanColumn('Completed', done, const Color(0xFF10B981), cardBg, cardBorder, textTitle, textSub)),
              ],
            );
          },
        ),
      ],
    );
  }

  Widget _buildKanbanColumn(String title, List<dynamic> list, Color headerColor, Color cardBg, Color cardBorder, Color textTitle, Color textSub) {
    final isDark = ThemeController.isDarkMode.value;
    // Solid background taaki botanical leaves peeche se text ko blur na karein
    final taskCardBg = isDark ? const Color(0xFF0F172A) : Colors.white;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: cardBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Column Header (Title + Count badge)
          Row(
            children: [
              Container(width: 10, height: 10, decoration: BoxDecoration(color: headerColor, shape: BoxShape.circle)),
              const SizedBox(width: 8),
              Text(title, style: TextStyle(color: textTitle, fontWeight: FontWeight.bold, fontSize: 14)),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(color: headerColor.withValues(alpha: 0.15), borderRadius: BorderRadius.circular(10)),
                child: Text('${list.length}', style: TextStyle(color: headerColor, fontWeight: FontWeight.bold, fontSize: 11)),
              ),
            ],
          ),
          const SizedBox(height: 14),
          if (list.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 28),
              child: Center(child: Text('No tasks', style: TextStyle(color: textSub, fontSize: 12))),
            )
          else
            ...list.map((task) {
              final subtasks = (task['subtasks'] as List<dynamic>?) ?? [];
              final doneSubtasks = subtasks.where((s) => s['is_completed'] == 1 || s['is_completed'] == true).length;
              final priority = (task['priority'] ?? 'MEDIUM').toString().toUpperCase();

              Color priColor = Colors.grey;
              if (priority == 'URGENT') priColor = const Color(0xFFEF4444);
              if (priority == 'HIGH') priColor = const Color(0xFFF97316);
              if (priority == 'MEDIUM') priColor = const Color(0xFFF59E0B);
              if (priority == 'LOW') priColor = const Color(0xFF10B981);

              final workerName = (task['assigned_worker'] != null && task['assigned_worker'].toString().isNotEmpty)
                  ? task['assigned_worker'].toString()
                  : 'Unassigned';

              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: taskCardBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: cardBorder),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.04),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Material(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(12),
                    // 👈 Card par click karne se sari details open hongi!
                    onTap: () => _openTaskDetailsDialog(task),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Top Row: Priority Tag + Edit & Delete Buttons
                          Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                decoration: BoxDecoration(
                                  color: priColor.withValues(alpha: 0.12),
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  priority,
                                  style: TextStyle(color: priColor, fontSize: 9.5, fontWeight: FontWeight.bold),
                                ),
                              ),
                              const Spacer(),
                              // ✏️ Edit Task Button
                              IconButton(
                                icon: const Icon(Icons.edit_outlined, size: 15, color: Color(0xFF10B981)),
                                tooltip: 'Edit Task',
                                splashRadius: 14,
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(minWidth: 24, minHeight: 24),
                                onPressed: () => _openEditTaskDialog(task),
                              ),
                              const SizedBox(width: 4),
                              // 🗑️ Delete Task Button
                              IconButton(
                                icon: const Icon(Icons.delete_outline, size: 15, color: Colors.redAccent),
                                tooltip: 'Delete Task',
                                splashRadius: 14,
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(minWidth: 24, minHeight: 24),
                                onPressed: () => _confirmDeleteTask(task),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),

                          // Task Title
                          Text(
                            task['title'] ?? 'Untitled',
                            style: TextStyle(color: textTitle, fontWeight: FontWeight.bold, fontSize: 13.5),
                          ),
                          if (task['description'] != null && task['description'].toString().isNotEmpty) ...[
                            const SizedBox(height: 4),
                            Text(
                              task['description'],
                              style: TextStyle(color: textSub, fontSize: 11.5, height: 1.3),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],

                          // Subtasks Checklist Count Badge
                          if (subtasks.isNotEmpty) ...[
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Icon(Icons.playlist_add_check_rounded, size: 14, color: textSub),
                                const SizedBox(width: 4),
                                Text(
                                  '$doneSubtasks/${subtasks.length} subtasks',
                                  style: TextStyle(color: textSub, fontSize: 10.5, fontWeight: FontWeight.w600),
                                ),
                              ],
                            ),
                          ],

                          const SizedBox(height: 10),

                          // Bottom Row: Worker Avatar & Name + Move ➔ Button
                          Row(
                            children: [
                              CircleAvatar(
                                radius: 8,
                                backgroundColor: const Color(0xFF10B981),
                                child: Text(
                                  workerName.isNotEmpty ? workerName[0].toUpperCase() : 'W',
                                  style: const TextStyle(fontSize: 8, color: Colors.white, fontWeight: FontWeight.bold),
                                ),
                              ),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  workerName,
                                  style: TextStyle(color: textTitle, fontSize: 11.5),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  final next = task['status'] == 'TODO'
                                      ? 'IN_PROGRESS'
                                      : (task['status'] == 'IN_PROGRESS' ? 'DONE' : 'TODO');
                                  _updateTaskStatus(task['task_id'], next);
                                },
                                borderRadius: BorderRadius.circular(8),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
                                  decoration: BoxDecoration(
                                    color: headerColor.withValues(alpha: 0.18),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text('Move ➔', style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.bold)),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
  // ================= 🏗️ CLEAN MOBILE-FRIENDLY WORKSPACE HEADER =================
  Widget _buildProjectWorkspaceView(Color cardBg, Color cardBorder, Color textTitle, Color textSub, bool isDark) {
    final prj = _selectedProject!;
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 700;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // 1. MODERN PROJECT HERO CARD
        Container(
          padding: EdgeInsets.all(isMobile ? 14 : 18),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF0F172A) : Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: cardBorder),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: isDark ? 0.3 : 0.04),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Row 1: Back Button + Code + Title + Status + Action Buttons
              Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back_rounded, color: textTitle, size: 20),
                    onPressed: () => setState(() => _selectedProject = null),
                    tooltip: 'Back to Projects',
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: const Color(0xFF10B981).withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(6),
                      border: Border.all(color: const Color(0xFF10B981).withValues(alpha: 0.3)),
                    ),
                    child: Text(
                      prj['project_code'] ?? 'PRJ',
                      style: const TextStyle(color: Color(0xFF059669), fontSize: 11, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Row(
                      children: [
                        Flexible(
                          child: Text(
                            prj['project_name'] ?? 'Untitled Project',
                            style: TextStyle(color: textTitle, fontSize: isMobile ? 16 : 18, fontWeight: FontWeight.bold),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2.5),
                          decoration: BoxDecoration(
                            color: const Color(0xFF059669).withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            prj['status'] ?? 'Active',
                            style: const TextStyle(color: Color(0xFF059669), fontSize: 10.5, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF059669),
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(horizontal: isMobile ? 12 : 16, vertical: isMobile ? 8 : 10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      elevation: 1,
                    ),
                    onPressed: () => _openCreateTaskDialog(preselectedProjectId: prj['project_id']),
                    icon: const Icon(Icons.add, size: 16),
                    label: Text(isMobile ? 'Task' : 'New Task', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(width: 6),
                  PopupMenuButton<String>(
                    icon: Icon(Icons.more_vert, size: 20, color: textSub),
                    padding: EdgeInsets.zero,
                    onSelected: (val) {
                      if (val == 'edit') _openEditProjectDialog(prj);
                      if (val == 'delete') _confirmDeleteProject(prj);
                    },
                    itemBuilder: (ctx) => [
                      const PopupMenuItem(value: 'edit', child: Row(children: [Icon(Icons.edit_outlined, size: 16, color: Color(0xFF10B981)), SizedBox(width: 8), Text('Edit Project')])),
                      const PopupMenuItem(value: 'delete', child: Row(children: [Icon(Icons.delete_outline, size: 16, color: Colors.redAccent), SizedBox(width: 8), Text('Delete Project', style: TextStyle(color: Colors.redAccent))])),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Divider(height: 1, color: cardBorder.withValues(alpha: 0.6)),
              const SizedBox(height: 12),

              // Row 2: Lead Name, Client Name & Project Task Progress Bar
              Builder(
                builder: (context) {
                  final allTasks = (_projectDetails?['tasks'] as List<dynamic>?) ?? [];
                  final totalTasks = allTasks.length;
                  final doneTasks = allTasks.where((t) => t['status'] == 'DONE').length;
                  final double progress = totalTasks > 0 ? (doneTasks / totalTasks) : 0.0;

                  return Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: isDark ? Colors.white.withValues(alpha: 0.04) : const Color(0xFFF1F5F9),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.person_pin_circle_outlined, size: 14, color: Color(0xFF059669)),
                            const SizedBox(width: 5),
                            Text('Lead: ${prj['leader_name'] ?? 'Unassigned'}', style: TextStyle(color: textTitle, fontSize: 11.5, fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: isDark ? Colors.white.withValues(alpha: 0.04) : const Color(0xFFF1F5F9),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.business_outlined, size: 14, color: Color(0xFF3B82F6)),
                            const SizedBox(width: 5),
                            Text('Client: ${prj['client_name'] ?? 'Internal'}', style: TextStyle(color: textTitle, fontSize: 11.5, fontWeight: FontWeight.w600)),
                          ],
                        ),
                      ),
                      const Spacer(),
                      // Progress Percentage Indicator
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            '$doneTasks/$totalTasks Done (${(progress * 100).toInt()}%)',
                            style: TextStyle(color: textSub, fontSize: 11.5, fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(width: 8),
                          SizedBox(
                            width: isMobile ? 60 : 120,
                            height: 6,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(6),
                              child: LinearProgressIndicator(
                                value: progress,
                                backgroundColor: isDark ? Colors.white12 : const Color(0xFFE2E8F0),
                                valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFF059669)),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  );
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),

        // 2. MINIMAL FLAT UNDERLINE TABS (Directly on page, no card!)
        TabBar(
          controller: _tabController,
          isScrollable: true,
          tabAlignment: TabAlignment.start,
          labelColor: const Color(0xFF10B981),
          unselectedLabelColor: textSub,
          indicatorColor: const Color(0xFF10B981),
          indicatorWeight: 2.5,
          labelPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 4),
          dividerColor: cardBorder.withValues(alpha: 0.5),
          tabs: const [
            Tab(text: 'Tasks & Checklist'),
            Tab(text: 'Team Members'),
            Tab(text: 'Timesheets'),
            Tab(text: 'Components'),
          ],
        ),
        const SizedBox(height: 20),

        if (_isLoadingDetails)
          const Center(child: Padding(padding: EdgeInsets.all(40), child: CircularProgressIndicator(color: Color(0xFF10B981))))
        else
          SizedBox(
            height: 650,
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildProjectTasksTab(cardBg, cardBorder, textTitle, textSub),
                _buildProjectTeamTab(cardBg, cardBorder, textTitle, textSub),
                _buildProjectTimesheetTab(cardBg, cardBorder, textTitle, textSub),
                _buildProjectComponentsTab(cardBg, cardBorder, textTitle, textSub),
              ],
            ),
          ),
      ],
    );
  }
  // ================= 📋 MOBILE + DESKTOP RESPONSIVE TASK VIEW =================
  Widget _buildProjectTasksTab(Color cardBg, Color cardBorder, Color textTitle, Color textSub) {
    final prj = _selectedProject!;
    final allTasks = (_projectDetails?['tasks'] as List<dynamic>?) ?? [];
    final isDark = ThemeController.isDarkMode.value;
    final screenWidth = MediaQuery.of(context).size.width;
    final isMobile = screenWidth < 700;

    // Solid Background so leaves don't bleed through
    final taskCardBg = isDark ? const Color(0xFF0F172A) : Colors.white;

    // Filter
    final filteredTasks = allTasks.where((task) {
      final title = (task['title'] ?? '').toString().toLowerCase();
      final desc = (task['description'] ?? '').toString().toLowerCase();
      final worker = (task['assigned_worker'] ?? '').toString().toLowerCase();
      final matchesQuery = _taskSearchQuery.isEmpty ||
          title.contains(_taskSearchQuery) ||
          desc.contains(_taskSearchQuery) ||
          worker.contains(_taskSearchQuery);

      if (!matchesQuery) return false;

      final status = (task['status'] ?? 'TODO').toString().toUpperCase();
      if (_selectedStatusFilter == 'ALL') return true;
      if (_selectedStatusFilter == 'TODO') return status == 'TODO';
      if (_selectedStatusFilter == 'IN_PROGRESS') return status == 'IN_PROGRESS';
      if (_selectedStatusFilter == 'DONE') return status == 'DONE';

      return true;
    }).toList();

    final totalCount = allTasks.length;
    final todoCount = allTasks.where((t) => (t['status'] ?? 'TODO') == 'TODO').length;
    final inProgressCount = allTasks.where((t) => t['status'] == 'IN_PROGRESS').length;
    final doneCount = allTasks.where((t) => t['status'] == 'DONE').length;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 1. CLEAN SEARCH & FILTER ROW (Directly on page, no wrapper card!)
          if (isMobile) ...[
            // Mobile: Search on top
            TextField(
              controller: _taskSearchController,
              onChanged: (val) => setState(() => _taskSearchQuery = val.trim().toLowerCase()),
              style: TextStyle(color: textTitle, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Search tasks...',
                hintStyle: TextStyle(color: textSub, fontSize: 12),
                prefixIcon: Icon(Icons.search, size: 18, color: textSub),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                filled: true,
                fillColor: taskCardBg,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: cardBorder)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: cardBorder)),
              ),
            ),
            const SizedBox(height: 12),
            // Filter chips scrollable
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildStatusFilterChip('ALL', 'All ($totalCount)'),
                  _buildStatusFilterChip('TODO', 'To Do ($todoCount)'),
                  _buildStatusFilterChip('IN_PROGRESS', 'In Progress ($inProgressCount)'),
                  _buildStatusFilterChip('DONE', 'Done ($doneCount)'),
                ],
              ),
            ),
          ] else ...[
            // Desktop: Search + Filters in one clean horizontal line
            Row(
              children: [
                SizedBox(
                  width: 240,
                  height: 38,
                  child: TextField(
                    controller: _taskSearchController,
                    onChanged: (val) => setState(() => _taskSearchQuery = val.trim().toLowerCase()),
                    style: TextStyle(color: textTitle, fontSize: 13),
                    decoration: InputDecoration(
                      hintText: 'Search tasks...',
                      hintStyle: TextStyle(color: textSub, fontSize: 12),
                      prefixIcon: Icon(Icons.search, size: 17, color: textSub),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      filled: true,
                      fillColor: taskCardBg,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide(color: cardBorder)),
                      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: BorderSide(color: cardBorder)),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        _buildStatusFilterChip('ALL', 'All ($totalCount)'),
                        _buildStatusFilterChip('TODO', 'To Do ($todoCount)'),
                        _buildStatusFilterChip('IN_PROGRESS', 'In Progress ($inProgressCount)'),
                        _buildStatusFilterChip('DONE', 'Done ($doneCount)'),
                      ],
                    ),
                  ),
                ),
                Text(
                  '$doneCount of $totalCount completed',
                  style: TextStyle(color: textSub, fontSize: 12, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ],
          const SizedBox(height: 20),

          // 2. CLEAN INDIVIDUAL TASK CARDS (Readable, Solid & Mobile Responsive)
          if (filteredTasks.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.all(40),
                child: Text('No tasks found. Click "+ New Task" above!', style: TextStyle(color: textSub)),
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: filteredTasks.length,
              itemBuilder: (context, idx) {
                final t = filteredTasks[idx];
                final subtasks = (t['subtasks'] as List<dynamic>?) ?? [];
                final doneSubtasks = subtasks.where((s) => s['is_completed'] == 1 || s['is_completed'] == true).length;
                final priority = (t['priority'] ?? 'MEDIUM').toString().toUpperCase();
                final isDone = t['status'] == 'DONE';

                Color priColor = Colors.grey;
                if (priority == 'URGENT') priColor = const Color(0xFFEF4444);
                if (priority == 'HIGH') priColor = const Color(0xFFF97316);
                if (priority == 'MEDIUM') priColor = const Color(0xFFF59E0B);
                if (priority == 'LOW') priColor = const Color(0xFF10B981);

                return Container(
                  margin: const EdgeInsets.only(bottom: 14),
                  padding: EdgeInsets.symmetric(
                    horizontal: isMobile ? 14 : 18,
                    vertical: isMobile ? 12 : 16,
                  ),
                  decoration: BoxDecoration(
                    color: taskCardBg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: cardBorder),
                    // Left border gives a modern Kanban card feel based on priority:
                    boxShadow: [
                      BoxShadow(
                        color: priColor.withValues(alpha: 0.3),
                        offset: const Offset(-4, 0), // Priority line (Red for urgent, Orange for High/Medium)
                        blurRadius: 0,
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // TOP ROW: Checkbox + Title + Action Icons
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          InkWell(
                            borderRadius: BorderRadius.circular(4),
                            onTap: () {
                              final next = isDone ? 'TODO' : 'DONE';
                              _updateTaskStatus(t['task_id'], next);
                            },
                            child: Padding(
                              padding: const EdgeInsets.only(top: 1, right: 10),
                              child: Icon(
                                isDone ? Icons.check_box_rounded : Icons.check_box_outline_blank_rounded,
                                color: isDone ? const Color(0xFF10B981) : textSub,
                                size: 21,
                              ),
                            ),
                          ),
                          Expanded(
                            child: InkWell(
                              borderRadius: BorderRadius.circular(8),
                              onTap: () => _openTaskDetailsDialog(t),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(vertical: 2.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            t['title'],
                                            style: TextStyle(
                                              color: isDone ? textSub : textTitle,
                                              fontSize: 14.5,
                                              fontWeight: FontWeight.bold,
                                              decoration: isDone ? TextDecoration.lineThrough : null,
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 4),
                                        Icon(Icons.arrow_forward_ios_rounded, size: 12, color: textSub.withValues(alpha: 0.4)),
                                      ],
                                    ),
                                    if (t['description'] != null && t['description'].toString().isNotEmpty) ...[
                                      const SizedBox(height: 5),
                                      Text(
                                        t['description'],
                                        style: TextStyle(color: textSub, fontSize: 12, height: 1.3),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          // Edit Button
                          IconButton(
                            icon: const Icon(Icons.edit_outlined, size: 17, color: Color(0xFF10B981)),
                            tooltip: 'Edit Task',
                            splashRadius: 16,
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                            onPressed: () => _openTaskDetailsDialog(t),
                          ),
                          const SizedBox(width: 4),
                          // Delete Button
                          IconButton(
                            icon: const Icon(Icons.delete_outline, size: 17, color: Colors.redAccent),
                            tooltip: 'Delete Task',
                            splashRadius: 16,
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                            onPressed: () => _confirmDeleteTask(t),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),

                      // MIDDLE ROW: Subtasks Checklist (Agar hain)
                      if (subtasks.isNotEmpty) ...[
                        Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          decoration: BoxDecoration(
                            color: isDark ? Colors.white.withValues(alpha: 0.04) : const Color(0xFFF8FAFC),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ...subtasks.map((st) {
                                final stDone = st['is_completed'] == 1 || st['is_completed'] == true;
                                return Padding(
                                  padding: const EdgeInsets.symmetric(vertical: 3.0),
                                  child: Row(
                                    children: [
                                      SizedBox(
                                        width: 18,
                                        height: 18,
                                        child: Checkbox(
                                          value: stDone,
                                          activeColor: const Color(0xFF10B981),
                                          visualDensity: VisualDensity.compact,
                                          onChanged: (val) => _toggleSubtask(st['subtask_id'], val ?? false),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          st['title'],
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: stDone ? textSub : textTitle,
                                            decoration: stDone ? TextDecoration.lineThrough : null,
                                          ),
                                        ),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.close, size: 14, color: Colors.redAccent),
                                        padding: EdgeInsets.zero,
                                        constraints: const BoxConstraints(minWidth: 20, minHeight: 20),
                                        onPressed: () async {
                                          try {
                                            await http.delete(Uri.parse('http://localhost:5000/api/projects/subtasks/${st['subtask_id']}'));
                                            if (_selectedProject != null) _fetchProjectDetails(_selectedProject!['project_id']);
                                          } catch (_) {}
                                        },
                                      ),
                                    ],
                                  ),
                                );
                              }),
                            ],
                          ),
                        ),
                      ],

                      // BOTTOM ROW: Badges (Wrap for clean Mobile & Desktop wrapping)
                      Wrap(
                        spacing: 12,
                        runSpacing: 8,
                        crossAxisAlignment: WrapCrossAlignment.center,
                        children: [
                          // Worker
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              CircleAvatar(
                                radius: 9,
                                backgroundColor: const Color(0xFF10B981),
                                child: Text(
                                  (t['assigned_worker'] != null && t['assigned_worker'].isNotEmpty) ? t['assigned_worker'][0].toUpperCase() : 'W',
                                  style: const TextStyle(fontSize: 8.5, color: Colors.white, fontWeight: FontWeight.bold),
                                ),
                              ),
                              const SizedBox(width: 6),
                              Text(t['assigned_worker'] ?? 'Unassigned', style: TextStyle(color: textTitle, fontSize: 12)),
                            ],
                          ),

                          // Priority
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3.5),
                            decoration: BoxDecoration(color: priColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(6)),
                            child: Text(priority, style: TextStyle(color: priColor, fontSize: 10.5, fontWeight: FontWeight.bold)),
                          ),

                          // Status Pill (Clickable)
                          InkWell(
                            borderRadius: BorderRadius.circular(6),
                            onTap: () {
                              final current = t['status'] ?? 'TODO';
                              final next = current == 'TODO' ? 'IN_PROGRESS' : (current == 'IN_PROGRESS' ? 'DONE' : 'TODO');
                              _updateTaskStatus(t['task_id'], next);
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3.5),
                              decoration: BoxDecoration(
                                color: (isDone ? const Color(0xFF10B981) : (t['status'] == 'IN_PROGRESS' ? const Color(0xFFD97706) : Colors.grey)).withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                t['status'] ?? 'TODO',
                                style: TextStyle(
                                  color: isDone ? const Color(0xFF10B981) : (t['status'] == 'IN_PROGRESS' ? const Color(0xFFD97706) : textSub),
                                  fontSize: 10.5,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),

                          // + Add Item Link
                          InkWell(
                            borderRadius: BorderRadius.circular(6),
                            onTap: () => _openAddSubtaskDialog(t['task_id'], t['title']),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: const [
                                  Icon(Icons.add_circle_outline, size: 14, color: Color(0xFF10B981)),
                                  SizedBox(width: 4),
                                  Text('+ Add item', style: TextStyle(color: Color(0xFF10B981), fontSize: 11.5, fontWeight: FontWeight.w600)),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
  // Filter Chip Helper
  Widget _buildStatusFilterChip(String key, String label) {
    final isSelected = _selectedStatusFilter == key;
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: FilterChip(
        label: Text(label),
        selected: isSelected,
        labelStyle: TextStyle(
          color: isSelected ? Colors.white : Colors.grey,
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          fontSize: 12,
        ),
        backgroundColor: Colors.transparent,
        selectedColor: const Color(0xFF10B981),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(
            color: isSelected ? const Color(0xFF10B981) : Colors.grey.withValues(alpha: 0.3),
          ),
        ),
        onSelected: (_) => setState(() => _selectedStatusFilter = key),
      ),
    );
  }

  // TAB 2: Team
  Widget _buildProjectTeamTab(Color cardBg, Color cardBorder, Color textTitle, Color textSub) {
    final members = (_projectDetails?['members'] as List<dynamic>?) ?? [];
    final isDark = ThemeController.isDarkMode.value;
    final itemBg = isDark ? const Color(0xFF0F172A) : Colors.white;

    return members.isEmpty
        ? Center(child: Text('No team members assigned yet.', style: TextStyle(color: textSub)))
        : GridView.builder(
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 320, mainAxisExtent: 76, crossAxisSpacing: 14, mainAxisSpacing: 14),
      itemCount: members.length,
      itemBuilder: (context, idx) {
        final m = members[idx];
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: itemBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: cardBorder),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.04),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: const Color(0xFF10B981).withValues(alpha: 0.15),
                child: Text(
                  m['full_name'] != null && m['full_name'].toString().isNotEmpty ? m['full_name'][0].toUpperCase() : 'M',
                  style: const TextStyle(color: Color(0xFF10B981), fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(m['full_name'] ?? 'Unnamed', style: TextStyle(color: textTitle, fontWeight: FontWeight.bold, fontSize: 13.5)),
                    const SizedBox(height: 2),
                    Text(m['role_in_project'] ?? 'Member', style: TextStyle(color: textSub, fontSize: 11.5)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // TAB 3: Timesheets
  Widget _buildProjectTimesheetTab(Color cardBg, Color cardBorder, Color textTitle, Color textSub) {
    final timesheets = (_projectDetails?['timesheets'] as List<dynamic>?) ?? [];
    final isDark = ThemeController.isDarkMode.value;
    final itemBg = isDark ? const Color(0xFF0F172A) : Colors.white;

    return timesheets.isEmpty
        ? Center(child: Text('No work hours logged yet for this project.', style: TextStyle(color: textSub)))
        : ListView.builder(
      itemCount: timesheets.length,
      itemBuilder: (context, idx) {
        final ts = timesheets[idx];
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            color: itemBg,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: cardBorder),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.04),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Row(
            children: [
              const Icon(Icons.timer_outlined, color: Color(0xFFD97706), size: 19),
              const SizedBox(width: 12),
              Expanded(
                child: Text('${ts['worker_name']} logged ${ts['hours_spent']} hrs: ${ts['description'] ?? ''}', style: TextStyle(color: textTitle, fontSize: 13)),
              ),
            ],
          ),
        );
      },
    );
  }

  // TAB 4: Components / Materials
  // TAB 4: Components / Materials
  Widget _buildProjectComponentsTab(Color cardBg, Color cardBorder, Color textTitle, Color textSub) {
    final prj = _selectedProject!;
    final materials = (_projectDetails?['materials'] as List<dynamic>?) ?? [];
    final isDark = ThemeController.isDarkMode.value;
    final itemBg = isDark ? const Color(0xFF0F172A) : Colors.white;

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top Toolbar: Header + Add Component Button
          Row(
            children: [
              Text(
                'Components & Parts (${materials.length})',
                style: TextStyle(color: textTitle, fontSize: 15, fontWeight: FontWeight.bold),
              ),
              const Spacer(),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2563EB),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  elevation: 0,
                ),
                onPressed: () => _openAddComponentDialog(prj['project_id']),
                icon: const Icon(Icons.add, size: 16),
                label: const Text('+ Add Component', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          const SizedBox(height: 16),

          if (materials.isEmpty)
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 40),
                child: Column(
                  children: [
                    Icon(Icons.inventory_2_outlined, size: 40, color: textSub.withValues(alpha: 0.5)),
                    const SizedBox(height: 10),
                    Text('No components or parts assigned yet.', style: TextStyle(color: textSub)),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF2563EB), side: const BorderSide(color: Color(0xFF2563EB))),
                      onPressed: () => _openAddComponentDialog(prj['project_id']),
                      icon: const Icon(Icons.add, size: 16),
                      label: const Text('Add Component Now'),
                    ),
                  ],
                ),
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: materials.length,
              itemBuilder: (context, idx) {
                final m = materials[idx];
                final status = (m['status'] ?? 'Required').toString();

                Color statusColor = const Color(0xFF2563EB); // Blue for Issued
                if (status == 'Required') statusColor = const Color(0xFFF59E0B);
                if (status == 'Consumed') statusColor = const Color(0xFF10B981);
                if (status == 'Returned') statusColor = Colors.grey;

                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  decoration: BoxDecoration(
                    color: itemBg,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: cardBorder),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: isDark ? 0.25 : 0.04),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: const Color(0xFF2563EB).withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(Icons.memory_rounded, color: Color(0xFF2563EB), size: 18),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              m['material_name'] ?? 'Unnamed Component',
                              style: TextStyle(color: textTitle, fontSize: 13.5, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              'Required: ${m['quantity_required']} ${m['unit'] ?? 'PCS'}',
                              style: TextStyle(color: textSub, fontSize: 11.5),
                            ),
                          ],
                        ),
                      ),
                      // Status Badge
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: statusColor.withValues(alpha: 0.12),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          status,
                          style: TextStyle(color: statusColor, fontSize: 11, fontWeight: FontWeight.bold),
                        ),
                      ),
                      const SizedBox(width: 8),
                      // 🗑️ Delete Component Button
                      IconButton(
                        icon: const Icon(Icons.delete_outline, size: 17, color: Colors.redAccent),
                        tooltip: 'Remove Component',
                        splashRadius: 16,
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
                        onPressed: () => _confirmDeleteComponent(m),
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
}